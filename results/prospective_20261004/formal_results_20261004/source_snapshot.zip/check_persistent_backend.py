"""Verify sequential and cross-process outputs against the fresh worker."""
import os
for n in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[n]='1'
from concurrent.futures import ProcessPoolExecutor
import hashlib,json,multiprocessing as mp,subprocess,sys,time
from pathlib import Path
import numpy as np
from persistent_backend import CHANNELS,initialize,evaluate
from run_pilot import stimulus

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'formal_development'

def fresh(request):
    p=subprocess.run([sys.executable,str(ROOT/'_prospective_worker.py'),json.dumps({'tstop':1500,'observable':'motor_voltage',**request})],capture_output=True,text=True,check=True)
    lines=[x[7:] for x in p.stdout.splitlines() if x.startswith('RESULT ')]
    return np.asarray(json.loads(lines[0])['motor'],dtype=float)

def main():
    OUT.mkdir(exist_ok=True)
    zero={c:0. for c in CHANNELS}
    a={'stimulus':stimulus('olfactory',-5.),'log_gains':zero}
    b={'stimulus':stimulus('posterior',5.),'log_gains':{**zero,'nca':.001,'irk':-.003,'slo1_egl19':.25}}
    c={'stimulus':stimulus('chemical',5.,'ramp'),'log_gains':{x:float(.2*np.sin(i)) for i,x in enumerate(CHANNELS)}}
    refs=[fresh(x) for x in (a,b,c)]
    results=[]
    with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'),initializer=initialize) as pool:
        outputs=list(pool.map(evaluate,[a,b,c,c,b,a,a,c,b,a]))
    for i,(response,metadata) in enumerate(outputs):
        index=[0,1,2,2,1,0,0,2,1,0][i]
        np.testing.assert_array_equal(response,refs[index])
        results.append({'position':i,'reference':index,'max_abs_mV':float(np.max(np.abs(response-refs[index]))),**metadata})
    report={'status':'PASS','fresh_process_references':3,'pooled_rollouts':len(results),'sequential_state_reset_and_cross_process_exact_parity':True,'backend_sha256':hashlib.sha256((ROOT/'persistent_backend.py').read_bytes()).hexdigest(),'checks':results}
    (OUT/'persistent_backend_parity.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
