"""Development test on an already exposed pilot truth, not test evidence."""
import os
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[name]='1'
import hashlib,json,time
from pathlib import Path
import numpy as np
from nonlinear_engine import Backend,fit,fitted_ensemble
from run_pilot import stimulus

ROOT=Path(__file__).resolve().parent

def main():
    out=ROOT/'formal_development';out.mkdir(exist_ok=True)
    report=json.loads((ROOT/'pilot_results/pilot_report.json').read_text())
    truth=np.asarray(report['trials'][0]['true_log_gains'])
    stim=stimulus('olfactory',-5.)
    backend=Backend(out,n_workers=24)
    try:
        true_y=backend.one(stim,truth);obs=true_y+np.random.default_rng(44013).normal(size=true_y.shape)
        began=time.time()
        fits=[]
        for i,start in enumerate((np.zeros(16),np.random.default_rng(5519).normal(0,.1,16))):
            result=fit(backend,[stim],[obs],start)
            fits.append(result)
            print('Development fit '+str(i)+' '+json.dumps({k:result[k] for k in ('training_RMSE_mV','termination','iterations','noise_matched')}),flush=True)
            (out/f'development_fit_{i}.json').write_text(json.dumps(result,indent=2))
        best=min(fits,key=lambda x:x['objective'])
        if not best['noise_matched']:raise RuntimeError('Development nonlinear fit did not match known observation noise')
        points,info=fitted_ensemble(backend,stim,obs,best,19054)
        J=info.pop('base_J')
        np.savez_compressed(out/'development_ensemble.npz',points=points,base_J=J,baseline_observation=obs)
        d={'status':'PASS','phase':'development on exposed pilot truth','engine_sha256':hashlib.sha256((ROOT/'nonlinear_engine.py').read_bytes()).hexdigest(),'fits':fits,'ensemble':info,'elapsed_sec':time.time()-began,'retained_rollouts':backend.count}
        (out/'nonlinear_development_report.json').write_text(json.dumps(d,indent=2))
        print('DEVELOPMENT PASS '+json.dumps({'elapsed_sec':d['elapsed_sec'],'rollouts':backend.count,'ensemble_size':len(points)}),flush=True)
    finally:backend.close()

if __name__=='__main__':main()
