"""Lock the source snapshot and start the authorized formal experiment."""
import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
directory=root/'formal_results_20261004'
directory.mkdir(exist_ok=True)
if (directory/'formal_report.json').exists():raise RuntimeError('Formal experiment is already complete')
if (directory/'launch.json').exists():
    state=json.loads((directory/'launch.json').read_text())
    process=Path(f'/proc/{state["pid"]}/cmdline')
    if process.exists() and 'run_formal.py' in process.read_bytes().decode(errors='replace'):raise RuntimeError('Formal experiment already running')
subprocess.run([sys.executable,'-u',str(root/'develop_nonlinear_fit.py')],check=True)
with zipfile.ZipFile(directory/'source_snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in ('run_formal.py','nonlinear_engine.py','persistent_backend.py','_prospective_worker.py','_baai_worker_support.py','check_persistent_backend.py','develop_nonlinear_fit.py','launch_formal.py'):
        z.write(root/name,name)
with (directory/'run.log').open('a') as log:
    child=subprocess.Popen([sys.executable,'-u',str(root/'run_formal.py')],cwd=root,env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
state={'pid':child.pid,'started_epoch':time.time(),'source_snapshot_sha256':hashlib.sha256((directory/'source_snapshot.zip').read_bytes()).hexdigest(),'directory':str(directory)}
(directory/'launch.json').write_text(json.dumps(state,indent=2))
print('LAUNCHED '+json.dumps(state),flush=True)
